"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { UserIcon, Weight, Zap, Heart, Activity } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Loader2 } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

interface Exercise {
  id: string
  name: string
}

interface AppUser {
  id: string
  name: string
  email: string
}

interface StrengthAttempt {
  weight: number
  velocity: number
  is_1rm: boolean
}

const testCategories = [
  {
    id: "anthropometric",
    name: "Σωματομετρικά",
    icon: UserIcon,
    color: "bg-blue-500",
    tests: [
      { name: "Ύψος", unit: "cm", field: "height" },
      { name: "Βάρος", unit: "kg", field: "weight" },
      { name: "BMI", unit: "kg/m²", field: "bmi", calculated: true },
      { name: "Λιπώδης Ιστός", unit: "%", field: "fatTissue" },
      { name: "Μυϊκή Μάζα", unit: "%", field: "muscleMass" },
      { name: "Σπλαχνικό Λίπος", unit: "%", field: "visceralFat" },
      { name: "Περίμετρος Μηρού", unit: "cm", field: "thighCircumference" },
      { name: "Περίμετρος Χεριών", unit: "cm", field: "armCircumference" },
      { name: "Περίμετρος Στήθους", unit: "cm", field: "chestCircumference" },
      { name: "Περίμετρος Μέσης", unit: "cm", field: "waist" },
      { name: "Περίμετρος Ισχίων", unit: "cm", field: "hips" },
    ],
  },
  {
    id: "functional",
    name: "Λειτουργικά",
    icon: Activity,
    color: "bg-green-500",
    tests: [
      { name: "Σύνδρομο", unit: "selections", field: "syndrome", type: "multiselect" },
      { name: "Overhead Squat", unit: "selections", field: "overheadSquat", type: "multiselect" },
      { name: "Single Leg Squat", unit: "selections", field: "singleLegSquat", type: "multiselect" },
      { name: "Walking", unit: "selections", field: "walking", type: "multiselect" },
      { name: "FMS Tests", unit: "score", field: "fmsTests", type: "multiselect" },
      { name: "FCS", unit: "score", field: "fcs", max: 10 },
    ],
  },
  {
    id: "strength",
    name: "Δύναμης",
    icon: Weight,
    color: "bg-red-500",
    tests: [],
  },
  {
    id: "endurance",
    name: "Αντοχής",
    icon: Heart,
    color: "bg-purple-500",
    tests: [
      { name: "Max HR", unit: "bpm", field: "maxHR" },
      { name: "1min Resting HR", unit: "bpm", field: "restingHR1min" },
      { name: "VO2 Max", unit: "ml/kg/min", field: "vo2Max" },
    ],
  },
  {
    id: "jumping",
    name: "Άλματα",
    icon: Zap,
    color: "bg-yellow-500",
    tests: [
      { name: "Non-Counter Movement Jump", unit: "cm", field: "nonCounterMovementJump" },
      { name: "Counter Movement Jump", unit: "cm", field: "counterMovementJump" },
      { name: "Depth Jump", unit: "cm", field: "depthJump" },
      { name: "Broad Jump", unit: "cm", field: "broadJump" },
      { name: "Triple Hop (Αριστερό)", unit: "cm", field: "tripleHopLeft" },
      { name: "Triple Hop (Δεξί)", unit: "cm", field: "tripleHopRight" },
      { name: "Single Hop (Αριστερό)", unit: "cm", field: "singleHopLeft" },
      { name: "Single Hop (Δεξί)", unit: "cm", field: "singleHopRight" },
    ],
  },
]

export default function TestsPage() {
  const { toast } = useToast()
  const [users, setUsers] = useState<AppUser[]>([])
  const [exercises, setExercises] = useState<Exercise[]>([])
  const [selectedUser, setSelectedUser] = useState("")
  const [testData, setTestData] = useState({})
  const [activeCategory, setActiveCategory] = useState("anthropometric")
  const [notes, setNotes] = useState("")
  const [loading, setLoading] = useState(false)

  // Overhead Squat selections
  const [overheadSquatSelections, setOverheadSquatSelections] = useState<string[]>([])
  const [overheadSquatDialogOpen, setOverheadSquatDialogOpen] = useState(false)

  // Single Leg Squat selections
  const [singleLegSquatSelections, setSingleLegSquatSelections] = useState<string[]>([])
  const [singleLegSquatDialogOpen, setSingleLegSquatDialogOpen] = useState(false)

  // Walking selections
  const [walkingSelections, setWalkingSelections] = useState<string[]>([])
  const [walkingDialogOpen, setWalkingDialogOpen] = useState(false)

  // Syndrome selections
  const [syndromeSelections, setSyndromeSelections] = useState<string[]>([])
  const [syndromeDialogOpen, setSyndromeDialogOpen] = useState(false)

  // FMS Tests selections with scores
  const [fmsScores, setFmsScores] = useState<Record<string, number>>({})
  const [fmsDialogOpen, setFmsDialogOpen] = useState(false)

  // Strength test states
  const [selectedStrengthExercise, setSelectedStrengthExercise] = useState("")
  const [strengthAttempts, setStrengthAttempts] = useState<StrengthAttempt[]>([])
  const [currentWeight, setCurrentWeight] = useState("")
  const [currentVelocity, setCurrentVelocity] = useState("")

  // Endurance test states
  const [selectedPushUpExercise, setSelectedPushUpExercise] = useState("")
  const [selectedPullUpExercise, setSelectedPullUpExercise] = useState("")
  const [selectedMasExercise, setSelectedMasExercise] = useState("")
  const [pushUpReps, setPushUpReps] = useState("")
  const [pullUpReps, setPullUpReps] = useState("")

  // Farmer's walk
  const [farmerTime, setFarmerTime] = useState("")
  const [farmerSpeed, setFarmerSpeed] = useState("")
  const [farmerWeight, setFarmerWeight] = useState("")
  const [farmerDistance, setFarmerDistance] = useState("")

  // Sprint
  const [sprintTime, setSprintTime] = useState("")
  const [sprintDistance, setSprintDistance] = useState("")
  const [sprintSpeed, setSprintSpeed] = useState("")

  // MAS Test
  const [masTime, setMasTime] = useState("")
  const [masDistance, setMasDistance] = useState("")
  const [masResult, setMasResult] = useState("")

  useEffect(() => {
    fetchUsers()
    fetchExercises()
  }, [])

  useEffect(() => {
    if (masTime && masDistance) {
      const timeInSeconds = Number.parseFloat(masTime) * 60
      const distanceInMeters = Number.parseFloat(masDistance)
      if (timeInSeconds > 0 && distanceInMeters > 0) {
        const mas = (distanceInMeters / timeInSeconds).toFixed(2)
        setMasResult(mas)
      }
    }
  }, [masTime, masDistance])

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase.from("app_users").select("id, name, email").order("name")

      if (error) throw error
      setUsers(data || [])
    } catch (error) {
      console.error("Error fetching users:", error)
    }
  }

  const fetchExercises = async () => {
    try {
      const { data, error } = await supabase.from("exercises").select("id, name").order("name")

      if (error) throw error
      setExercises(data || [])
    } catch (error) {
      console.error("Error fetching exercises:", error)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setTestData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const calculateBMI = () => {
    const height = Number.parseFloat(testData.height || "0") / 100
    const weight = Number.parseFloat(testData.weight || "0")
    if (height > 0 && weight > 0) {
      return (weight / (height * height)).toFixed(1)
    }
    return ""
  }

  const addStrengthAttempt = () => {
    if (currentWeight && currentVelocity) {
      setStrengthAttempts((prev) => [
        ...prev,
        {
          weight: Number.parseFloat(currentWeight),
          velocity: Number.parseFloat(currentVelocity),
          is_1rm: false,
        },
      ])
      setCurrentWeight("")
      setCurrentVelocity("")
    }
  }

  const markAs1RM = (index: number) => {
    setStrengthAttempts((prev) =>
      prev.map((attempt, i) => ({
        ...attempt,
        is_1rm: i === index,
      })),
    )
  }

  const removeStrengthAttempt = (index: number) => {
    setStrengthAttempts((prev) => prev.filter((_, i) => i !== index))
  }

  const handleOverheadSquatChange = (option: string, checked: boolean) => {
    if (checked) {
      setOverheadSquatSelections((prev) => [...prev, option])
    } else {
      setOverheadSquatSelections((prev) => prev.filter((item) => item !== option))
    }
  }

  const handleSingleLegSquatChange = (option: string, checked: boolean) => {
    if (checked) {
      setSingleLegSquatSelections((prev) => [...prev, option])
    } else {
      setSingleLegSquatSelections((prev) => prev.filter((item) => item !== option))
    }
  }

  const handleWalkingChange = (option: string, checked: boolean) => {
    if (checked) {
      setWalkingSelections((prev) => [...prev, option])
    } else {
      setWalkingSelections((prev) => prev.filter((item) => item !== option))
    }
  }

  const handleSyndromeChange = (option: string, checked: boolean) => {
    if (checked) {
      setSyndromeSelections((prev) => [...prev, option])
    } else {
      setSyndromeSelections((prev) => prev.filter((item) => item !== option))
    }
  }

  const handleFmsScoreChange = (option: string) => {
    setFmsScores((prev) => {
      const currentScore = prev[option] || 0
      const nextScore = currentScore === 3 ? 0 : currentScore + 1
      return {
        ...prev,
        [option]: nextScore,
      }
    })
  }

  const calculateFmsTotal = () => {
    return Object.values(fmsScores).reduce((sum, score) => sum + score, 0)
  }

  const handleSaveTest = async () => {
    if (!selectedUser) {
      toast({
        title: "Error",
        description: "Παρακαλώ επιλέξτε αθλητή",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const finalData = {
        user_id: selectedUser,
        test_date: new Date().toISOString().split("T")[0],
        height: testData.height ? Number.parseFloat(testData.height) : null,
        weight: testData.weight ? Number.parseFloat(testData.weight) : null,
        bmi: calculateBMI() ? Number.parseFloat(calculateBMI()) : null,
        fat_tissue: testData.fatTissue ? Number.parseFloat(testData.fatTissue) : null,
        muscle_mass: testData.muscleMass ? Number.parseFloat(testData.muscleMass) : null,
        visceral_fat: testData.visceralFat ? Number.parseFloat(testData.visceralFat) : null,
        thigh_circumference: testData.thighCircumference ? Number.parseFloat(testData.thighCircumference) : null,
        arm_circumference: testData.armCircumference ? Number.parseFloat(testData.armCircumference) : null,
        chest_circumference: testData.chestCircumference ? Number.parseFloat(testData.chestCircumference) : null,
        waist: testData.waist ? Number.parseFloat(testData.waist) : null,
        hips: testData.hips ? Number.parseFloat(testData.hips) : null,

        // Functional tests
        syndrome_selections: syndromeSelections.length > 0 ? JSON.stringify(syndromeSelections) : null,
        overhead_squat_selections: overheadSquatSelections.length > 0 ? JSON.stringify(overheadSquatSelections) : null,
        single_leg_squat_selections:
          singleLegSquatSelections.length > 0 ? JSON.stringify(singleLegSquatSelections) : null,
        walking_selections: walkingSelections.length > 0 ? JSON.stringify(walkingSelections) : null,
        fms_scores: Object.keys(fmsScores).length > 0 ? JSON.stringify(fmsScores) : null,
        fms_total_score: calculateFmsTotal() || null,
        fcs: testData.fcs ? Number.parseFloat(testData.fcs) : null,

        // Strength data
        strength_exercise_id: selectedStrengthExercise || null,
        strength_attempts: strengthAttempts.length > 0 ? JSON.stringify(strengthAttempts) : null,
        one_rm: strengthAttempts.find((a) => a.is_1rm)?.weight || null,

        // Endurance data
        max_hr: testData.maxHR ? Number.parseFloat(testData.maxHR) : null,
        resting_hr_1min: testData.restingHR1min ? Number.parseFloat(testData.restingHR1min) : null,
        vo2_max: testData.vo2Max ? Number.parseFloat(testData.vo2Max) : null,
        push_up_exercise_id: selectedPushUpExercise || null,
        push_up_reps: pushUpReps ? Number.parseInt(pushUpReps) : null,
        pull_up_exercise_id: selectedPullUpExercise || null,
        pull_up_reps: pullUpReps ? Number.parseInt(pullUpReps) : null,
        farmer_time: farmerTime ? Number.parseFloat(farmerTime) : null,
        farmer_speed: farmerSpeed ? Number.parseFloat(farmerSpeed) : null,
        farmer_weight: farmerWeight ? Number.parseFloat(farmerWeight) : null,
        farmer_distance: farmerDistance ? Number.parseFloat(farmerDistance) : null,
        sprint_time: sprintTime ? Number.parseFloat(sprintTime) : null,
        sprint_distance: sprintDistance ? Number.parseFloat(sprintDistance) : null,
        sprint_speed: sprintSpeed ? Number.parseFloat(sprintSpeed) : null,
        mas_exercise_id: selectedMasExercise || null,
        mas_time: masTime ? Number.parseFloat(masTime) : null,
        mas_distance: masDistance ? Number.parseFloat(masDistance) : null,
        mas_result: masResult ? Number.parseFloat(masResult) : null,

        // Jumping tests
        non_counter_movement_jump: testData.nonCounterMovementJump
          ? Number.parseFloat(testData.nonCounterMovementJump)
          : null,
        counter_movement_jump: testData.counterMovementJump ? Number.parseFloat(testData.counterMovementJump) : null,
        depth_jump: testData.depthJump ? Number.parseFloat(testData.depthJump) : null,
        broad_jump: testData.broadJump ? Number.parseFloat(testData.broadJump) : null,
        triple_hop_left: testData.tripleHopLeft ? Number.parseFloat(testData.tripleHopLeft) : null,
        triple_hop_right: testData.tripleHopRight ? Number.parseFloat(testData.tripleHopRight) : null,
        single_hop_left: testData.singleHopLeft ? Number.parseFloat(testData.singleHopLeft) : null,
        single_hop_right: testData.singleHopRight ? Number.parseFloat(testData.singleHopRight) : null,

        // Notes
        notes: notes || null,
        created_at: new Date().toISOString(),
      }

      console.log("Sending data:", finalData)

      const { data, error } = await supabase.from("user_tests").insert([finalData]).select()

      if (error) {
        console.error("Supabase error:", error)
        toast({
          title: "Error",
          description: `Σφάλμα κατά την αποθήκευση: ${error.message}`,
          variant: "destructive",
        })
        return
      }

      console.log("Saved successfully:", data)

      toast({
        title: "Success",
        description: "Τα τεστ αποθηκεύτηκαν επιτυχώς στο προφίλ του χρήστη!",
      })

      // Reset form
      setTestData({})
      setNotes("")
      setOverheadSquatSelections([])
      setSingleLegSquatSelections([])
      setWalkingSelections([])
      setWalkingDialogOpen(false)
      setSingleLegSquatDialogOpen(false)
      setStrengthAttempts([])
      setSelectedStrengthExercise("")
      setPushUpReps("")
      setPullUpReps("")
      setFarmerTime("")
      setFarmerSpeed("")
      setFarmerWeight("")
      setFarmerDistance("")
      setSprintTime("")
      setSprintDistance("")
      setSprintSpeed("")
      setMasTime("")
      setMasDistance("")
      setMasResult("")
      setOverheadSquatDialogOpen(false)
      setSyndromeSelections([])
      setSyndromeDialogOpen(false)
      setFmsScores({})
      setFmsDialogOpen(false)
    } catch (error: any) {
      console.error("Catch error:", error)
      toast({
        title: "Error",
        description: `Σφάλμα κατά την αποθήκευση: ${error?.message || error?.toString() || "Άγνωστο σφάλμα"}`,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Τεστ Αξιολόγησης</h1>
          <p className="text-muted-foreground">Διαχείριση και καταγραφή τεστ αθλητών</p>
        </div>
        <Button onClick={handleSaveTest} disabled={loading} className="bg-green-600 hover:bg-green-700">
          {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : "Αποθήκευση Τεστ"}
        </Button>
      </div>

      {/* User Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserIcon className="h-5 w-5" />
            Επιλογή Αθλητή
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="user">Αθλητής</Label>
              <Select value={selectedUser} onValueChange={setSelectedUser}>
                <SelectTrigger>
                  <SelectValue placeholder="Επιλέξτε αθλητή..." />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name || user.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="testDate">Ημερομηνία Τεστ</Label>
              <Input id="testDate" type="date" defaultValue={new Date().toISOString().split("T")[0]} />
            </div>
            <div>
              <Label htmlFor="tester">Αξιολογητής</Label>
              <Input id="tester" placeholder="Όνομα αξιολογητή" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Test Categories */}
      <Tabs value={activeCategory} onValueChange={setActiveCategory}>
        <TabsList className="grid w-full grid-cols-5">
          {testCategories.map((category) => {
            const Icon = category.icon
            return (
              <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{category.name}</span>
              </TabsTrigger>
            )
          })}
        </TabsList>

        {/* Anthropometric Tests */}
        <TabsContent value="anthropometric">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-blue-500 text-white">
                  <UserIcon className="h-5 w-5" />
                </div>
                Τεστ Σωματομετρικά
              </CardTitle>
              <CardDescription>Καταγράψτε τα σωματομετρικά χαρακτηριστικά</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {testCategories[0].tests.map((test) => (
                  <div key={test.field} className="space-y-2">
                    <Label htmlFor={test.field} className="flex items-center justify-between">
                      {test.name}
                      <Badge className="bg-blue-100 text-blue-700">{test.unit}</Badge>
                    </Label>
                    <Input
                      id={test.field}
                      type="number"
                      step="0.1"
                      placeholder={`Εισάγετε ${test.unit}`}
                      value={test.calculated && test.field === "bmi" ? calculateBMI() : testData[test.field] || ""}
                      onChange={(e) => handleInputChange(test.field, e.target.value)}
                      disabled={test.calculated}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Functional Tests */}
        <TabsContent value="functional">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-green-500 text-white">
                  <Activity className="h-5 w-5" />
                </div>
                Τεστ Λειτουργικά
              </CardTitle>
              <CardDescription>Καταγράψτε τα λειτουργικά τεστ</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {testCategories[1].tests.map((test) => (
                  <div key={test.field} className="space-y-2">
                    <Label htmlFor={test.field} className="flex items-center justify-between">
                      {test.name}
                      {test.unit ? <Badge className="bg-blue-100 text-blue-700">{test.unit}</Badge> : null}
                    </Label>
                    {test.type === "multiselect" && test.field === "syndrome" ? (
                      <div className="space-y-2">
                        <Dialog open={syndromeDialogOpen} onOpenChange={setSyndromeDialogOpen}>
                          <DialogTrigger asChild>
                            <Button variant="outline" className="w-full justify-start">
                              {syndromeSelections.length > 0
                                ? `Επιλεγμένα: ${syndromeSelections.length} στοιχεία`
                                : "Κάντε κλικ για επιλογή..."}
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md bg-white border-0 shadow-lg">
                            <div className="bg-white rounded-lg">
                              <DialogHeader>
                                <DialogTitle>Σύνδρομο - Επιλογή Χαρακτηριστικών</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-3">
                                <div className="grid grid-cols-1 gap-3">
                                  <div>
                                    <div className="grid grid-cols-1 gap-1">
                                      {["ΚΥΦΩΣΗ", "ΛΟΡΔΩΣΗ", "ΠΡΗΝΙΣΜΟΣ"].map((option) => (
                                        <div
                                          key={option}
                                          className={`p-1.5 border rounded-md cursor-pointer transition-colors ${
                                            syndromeSelections.includes(option)
                                              ? "bg-blue-100 border-blue-500"
                                              : "hover:bg-gray-50"
                                          }`}
                                          onClick={() =>
                                            handleSyndromeChange(option, !syndromeSelections.includes(option))
                                          }
                                        >
                                          <div className="flex items-center justify-between">
                                            <span className="text-xs">{option}</span>
                                            {syndromeSelections.includes(option) && (
                                              <span className="text-blue-600 text-xs">✓</span>
                                            )}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>

                                <div className="flex justify-between items-center pt-3 border-t">
                                  <div className="text-xs text-muted-foreground">
                                    Επιλεγμένα: {syndromeSelections.length} στοιχεία
                                  </div>
                                  <div className="space-x-2">
                                    <Button variant="outline" size="sm" onClick={() => setSyndromeSelections([])}>
                                      Καθαρισμός
                                    </Button>
                                    <Button
                                      size="sm"
                                      onClick={() => setSyndromeDialogOpen(false)}
                                      className="bg-black hover:bg-gray-800 text-white"
                                    >
                                      Αποθήκευση
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>

                        {syndromeSelections.length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            <div className="flex flex-wrap gap-1 mt-2">
                              {syndromeSelections.map((selection) => (
                                <Badge key={selection} className="bg-blue-100 text-blue-700 text-xs">
                                  {selection}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : test.type === "multiselect" && test.field === "overheadSquat" ? (
                      <div className="space-y-2">
                        <Dialog open={overheadSquatDialogOpen} onOpenChange={setOverheadSquatDialogOpen}>
                          <DialogTrigger asChild>
                            <Button variant="outline" className="w-full justify-start">
                              {overheadSquatSelections.length > 0
                                ? `Επιλεγμένα: ${overheadSquatSelections.length} στοιχεία`
                                : "Κάντε κλικ για επιλογή..."}
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl bg-white border-0 shadow-lg">
                            <div className="bg-white rounded-lg">
                              <DialogHeader>
                                <DialogTitle>Overhead Squat - Επιλογή Χαρακτηριστικών</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-3">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                  <div>
                                    <h4 className="font-semibold mb-2 text-sm">Αριστερά</h4>
                                    <div className="grid grid-cols-1 gap-1">
                                      {[
                                        "ΕΞΩ ΣΤΡΟΦΗ ΠΕΛΜΑΤΩΝ ΑΡΙΣΤΕΡΑ",
                                        "ΠΡΗΝΙΣΜΟΣ ΠΕΛΜΑΤΩΝ ΑΡΙΣΤΕΡΑ",
                                        "ΕΣΩ ΣΤΡΟΦΗ ΓΩΝΑΤΩΝ ΑΡΙΣΤΕΡΑ",
                                        "ΕΞΩ ΣΤΡΟΦΗ ΓΩΝΑΤΩΝ ΑΡΙΣΤΕΡΑ",
                                        "ΑΝΥΨΩΣΗ ΦΤΕΡΝΩΝ ΑΡΙΣΤΕΡΑ",
                                        "ΜΕΤΑΦΟΡΑ ΒΑΡΟΥΣ ΑΡΙΣΤΕΡΑ",
                                      ].map((option) => (
                                        <div
                                          key={option}
                                          className={`p-1.5 border rounded-md cursor-pointer transition-colors ${
                                            overheadSquatSelections.includes(option)
                                              ? "bg-blue-100 border-blue-500"
                                              : "hover:bg-gray-50"
                                          }`}
                                          onClick={() =>
                                            handleOverheadSquatChange(option, !overheadSquatSelections.includes(option))
                                          }
                                        >
                                          <div className="flex items-center justify-between">
                                            <span className="text-xs">{option}</span>
                                            {overheadSquatSelections.includes(option) && (
                                              <span className="text-blue-600 text-xs">✓</span>
                                            )}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  <div>
                                    <h4 className="font-semibold mb-2 text-sm">Δεξιά</h4>
                                    <div className="grid grid-cols-1 gap-1">
                                      {[
                                        "ΕΞΩ ΣΤΡΟΦΗ ΠΕΛΜΑΤΩΝ ΔΕΞΙΑ",
                                        "ΠΡΗΝΙΣΜΟΣ ΠΕΛΜΑΤΩΝ ΔΕΞΙΑ",
                                        "ΕΣΩ ΣΤΡΟΦΗ ΓΩΝΑΤΩΝ ΔΕΞΙΑ",
                                        "ΕΞΩ ΣΤΡΟΦΗ ΓΩΝΑΤΩΝ ΔΕΞΙΑ",
                                        "ΑΝΥΨΩΣΗ ΦΤΕΡΝΩΝ ΔΕΞΙΑ",
                                        "ΜΕΤΑΦΟΡΑ ΒΑΡΟΥΣ ΔΕΞΙΑ",
                                      ].map((option) => (
                                        <div
                                          key={option}
                                          className={`p-1.5 border rounded-md cursor-pointer transition-colors ${
                                            overheadSquatSelections.includes(option)
                                              ? "bg-blue-100 border-blue-500"
                                              : "hover:bg-gray-50"
                                          }`}
                                          onClick={() =>
                                            handleOverheadSquatChange(option, !overheadSquatSelections.includes(option))
                                          }
                                        >
                                          <div className="flex items-center justify-between">
                                            <span className="text-xs">{option}</span>
                                            {overheadSquatSelections.includes(option) && (
                                              <span className="text-blue-600 text-xs">✓</span>
                                            )}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  <div className="md:col-span-2">
                                    <h4 className="font-semibold mb-2 text-sm">Κορμός & Χέρια</h4>
                                    <div className="grid grid-cols-2 gap-1">
                                      {[
                                        "ΕΜΠΡΟΣ ΚΛΙΣΗ ΤΟΥ ΚΟΡΜΟΥ",
                                        "ΥΠΕΡΕΚΤΑΣΗ ΣΤΗΝ Σ.Σ.",
                                        "ΚΥΦΩΤΙΚΗ ΘΕΣΗ ΣΤΗ Σ.Σ.",
                                        "ΠΤΩΣΗ ΧΕΡΙΩΝ",
                                      ].map((option) => (
                                        <div
                                          key={option}
                                          className={`p-1.5 border rounded-md cursor-pointer transition-colors ${
                                            overheadSquatSelections.includes(option)
                                              ? "bg-blue-100 border-blue-500"
                                              : "hover:bg-gray-50"
                                          }`}
                                          onClick={() =>
                                            handleOverheadSquatChange(option, !overheadSquatSelections.includes(option))
                                          }
                                        >
                                          <div className="flex items-center justify-between">
                                            <span className="text-xs">{option}</span>
                                            {overheadSquatSelections.includes(option) && (
                                              <span className="text-blue-600 text-xs">✓</span>
                                            )}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>

                                <div className="flex justify-between items-center pt-3 border-t">
                                  <div className="text-xs text-muted-foreground">
                                    Επιλεγμένα: {overheadSquatSelections.length} στοιχεία
                                  </div>
                                  <div className="space-x-2">
                                    <Button variant="outline" size="sm" onClick={() => setOverheadSquatSelections([])}>
                                      Καθαρισμός
                                    </Button>
                                    <Button
                                      size="sm"
                                      onClick={() => setOverheadSquatDialogOpen(false)}
                                      className="bg-black hover:bg-gray-800 text-white"
                                    >
                                      Αποθήκευση
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>

                        {overheadSquatSelections.length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            <div className="flex flex-wrap gap-1 mt-2">
                              {overheadSquatSelections.map((selection) => (
                                <Badge key={selection} className="bg-blue-100 text-blue-700 text-xs">
                                  {selection}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : test.type === "multiselect" && test.field === "singleLegSquat" ? (
                      <div className="space-y-2">
                        <Dialog open={singleLegSquatDialogOpen} onOpenChange={setSingleLegSquatDialogOpen}>
                          <DialogTrigger asChild>
                            <Button variant="outline" className="w-full justify-start">
                              {singleLegSquatSelections.length > 0
                                ? `Επιλεγμένα: ${singleLegSquatSelections.length} στοιχεία`
                                : "Κάντε κλικ για επιλογή..."}
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-xl bg-white border-0 shadow-lg">
                            <div className="bg-white rounded-lg">
                              <DialogHeader>
                                <DialogTitle>Single Leg Squat - Επιλογή Χαρακτηριστικών</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-3">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                  <div>
                                    <h4 className="font-semibold mb-2 text-sm">Αριστερά</h4>
                                    <div className="grid grid-cols-1 gap-1">
                                      {[
                                        "ΑΝΗΨΩΣΗ ΙΣΧΙΟΥ ΑΡΙΣΤΕΡΑ",
                                        "ΠΤΩΣΗ ΙΣΧΙΟΥ ΑΡΙΣΤΕΡΑ",
                                        "ΕΣΩ ΣΤΡΟΦΗ ΚΟΡΜΟΥ ΑΡΙΣΤΕΡΑ",
                                        "ΕΞΩ ΣΤΡΟΦΗ ΚΟΡΜΟΥ ΑΡΙΣΤΕΡΑ",
                                      ].map((option) => (
                                        <div
                                          key={option}
                                          className={`p-1.5 border rounded-md cursor-pointer transition-colors ${
                                            singleLegSquatSelections.includes(option)
                                              ? "bg-blue-100 border-blue-500"
                                              : "hover:bg-gray-50"
                                          }`}
                                          onClick={() =>
                                            handleSingleLegSquatChange(
                                              option,
                                              !singleLegSquatSelections.includes(option),
                                            )
                                          }
                                        >
                                          <div className="flex items-center justify-between">
                                            <span className="text-xs">{option}</span>
                                            {singleLegSquatSelections.includes(option) && (
                                              <span className="text-blue-600 text-xs">✓</span>
                                            )}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  <div>
                                    <h4 className="font-semibold mb-2 text-sm">Δεξιά</h4>
                                    <div className="grid grid-cols-1 gap-1">
                                      {[
                                        "ΑΝΗΨΩΣΗ ΙΣΧΙΟΥ ΔΕΞΙΑ",
                                        "ΠΤΩΣΗ ΙΣΧΙΟΥ ΔΕΞΙΑ",
                                        "ΕΣΩ ΣΤΡΟΦΗ ΚΟΡΜΟΥ ΔΕΞΙΑ",
                                        "ΕΞΩ ΣΤΡΟΦΗ ΚΟΡΜΟΥ ΔΕΞΙΑ",
                                      ].map((option) => (
                                        <div
                                          key={option}
                                          className={`p-1.5 border rounded-md cursor-pointer transition-colors ${
                                            singleLegSquatSelections.includes(option)
                                              ? "bg-blue-100 border-blue-500"
                                              : "hover:bg-gray-50"
                                          }`}
                                          onClick={() =>
                                            handleSingleLegSquatChange(
                                              option,
                                              !singleLegSquatSelections.includes(option),
                                            )
                                          }
                                        >
                                          <div className="flex items-center justify-between">
                                            <span className="text-xs">{option}</span>
                                            {singleLegSquatSelections.includes(option) && (
                                              <span className="text-blue-600 text-xs">✓</span>
                                            )}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>

                                <div className="flex justify-between items-center pt-3 border-t">
                                  <div className="text-xs text-muted-foreground">
                                    Επιλεγμένα: {singleLegSquatSelections.length} στοιχεία
                                  </div>
                                  <div className="space-x-2">
                                    <Button variant="outline" size="sm" onClick={() => setSingleLegSquatSelections([])}>
                                      Καθαρισμός
                                    </Button>
                                    <Button
                                      size="sm"
                                      onClick={() => setSingleLegSquatDialogOpen(false)}
                                      className="bg-black hover:bg-gray-800 text-white"
                                    >
                                      Αποθήκευση
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>

                        {singleLegSquatSelections.length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            <div className="flex flex-wrap gap-1 mt-2">
                              {singleLegSquatSelections.map((selection) => (
                                <Badge key={selection} className="bg-blue-100 text-blue-700 text-xs">
                                  {selection}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : test.type === "multiselect" && test.field === "walking" ? (
                      <div className="space-y-2">
                        <Dialog open={walkingDialogOpen} onOpenChange={setWalkingDialogOpen}>
                          <DialogTrigger asChild>
                            <Button variant="outline" className="w-full justify-start">
                              {walkingSelections.length > 0
                                ? `Επιλεγμένα: ${walkingSelections.length} στοιχεία`
                                : "Κάντε κλικ για επιλογή..."}
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md bg-white border-0 shadow-lg">
                            <div className="bg-white rounded-lg">
                              <DialogHeader>
                                <DialogTitle>Walking - Επιλογή Χαρακτηριστικών</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-3">
                                <div className="grid grid-cols-1 gap-3">
                                  <div>
                                    <div className="grid grid-cols-1 gap-1">
                                      {["ΕΥΘΕΙΑΣΜΟ", "ΣΤΡΟΦΗ ΛΕΚΑΝΗΣ", "ΜΕΤΑΦΟΡΑ ΒΑΡΟΥΣ"].map((option) => (
                                        <div
                                          key={option}
                                          className={`p-1.5 border rounded-md cursor-pointer transition-colors ${
                                            walkingSelections.includes(option)
                                              ? "bg-blue-100 border-blue-500"
                                              : "hover:bg-gray-50"
                                          }`}
                                          onClick={() =>
                                            handleWalkingChange(option, !walkingSelections.includes(option))
                                          }
                                        >
                                          <div className="flex items-center justify-between">
                                            <span className="text-xs">{option}</span>
                                            {walkingSelections.includes(option) && (
                                              <span className="text-blue-600 text-xs">✓</span>
                                            )}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>

                                <div className="flex justify-between items-center pt-3 border-t">
                                  <div className="text-xs text-muted-foreground">
                                    Επιλεγμένα: {walkingSelections.length} στοιχεία
                                  </div>
                                  <div className="space-x-2">
                                    <Button variant="outline" size="sm" onClick={() => setWalkingSelections([])}>
                                      Καθαρισμός
                                    </Button>
                                    <Button
                                      size="sm"
                                      onClick={() => setWalkingDialogOpen(false)}
                                      className="bg-black hover:bg-gray-800 text-white"
                                    >
                                      Αποθήκευση
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>

                        {walkingSelections.length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            <div className="flex flex-wrap gap-1 mt-2">
                              {walkingSelections.map((selection) => (
                                <Badge key={selection} className="bg-blue-100 text-blue-700 text-xs">
                                  {selection}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : test.type === "multiselect" && test.field === "fmsTests" ? (
                      <div className="space-y-2">
                        <Dialog open={fmsDialogOpen} onOpenChange={setFmsDialogOpen}>
                          <DialogTrigger asChild>
                            <Button variant="outline" className="w-full justify-start">
                              {Object.keys(fmsScores).length > 0
                                ? `Σκορ: ${calculateFmsTotal()}/21`
                                : "Κάντε κλικ για επιλογή..."}
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl bg-white border-0 shadow-lg">
                            <div className="bg-white rounded-lg">
                              <DialogHeader>
                                <DialogTitle>FMS Tests - Επιλογή & Βαθμολόγηση</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-3">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                  {[
                                    "Shoulder Mobility",
                                    "Active Straight-Leg Raise",
                                    "Trunk Stability Push-Up",
                                    "Rotary Stability",
                                    "In-Line Lunge",
                                    "Hurdle Step",
                                    "Deep Squat",
                                  ].map((option) => (
                                    <div key={option} className="p-2 border rounded-md">
                                      <div className="flex items-center justify-between">
                                        <span className="text-sm font-medium">{option}</span>
                                        <div className="flex items-center space-x-2">
                                          {[0, 1, 2, 3].map((score) => (
                                            <button
                                              key={score}
                                              className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                                                fmsScores[option] === score
                                                  ? score === 0
                                                    ? "bg-red-500"
                                                    : score === 1
                                                      ? "bg-yellow-500"
                                                      : score === 2
                                                        ? "bg-blue-500"
                                                        : "bg-green-500"
                                                  : "bg-gray-300 hover:bg-gray-400"
                                              }`}
                                              onClick={() =>
                                                setFmsScores((prev) => ({
                                                  ...prev,
                                                  [option]: prev[option] === score ? 0 : score,
                                                }))
                                              }
                                            >
                                              {score}
                                            </button>
                                          ))}
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                </div>

                                <div className="flex justify-between items-center pt-3 border-t">
                                  <div>
                                    <div className="text-xs text-muted-foreground">
                                      Επιλεγμένα: {Object.keys(fmsScores).length} στοιχεία
                                    </div>
                                    <div className="text-xs text-muted-foreground">
                                      Συνολικό Σκορ: {calculateFmsTotal()}/21
                                    </div>
                                  </div>
                                  <div className="space-x-2">
                                    <Button variant="outline" size="sm" onClick={() => setFmsScores({})}>
                                      Καθαρισμός
                                    </Button>
                                    <Button
                                      size="sm"
                                      onClick={() => setFmsDialogOpen(false)}
                                      className="bg-black hover:bg-gray-800 text-white"
                                    >
                                      Αποθήκευση
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>

                        {Object.keys(fmsScores).length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            <div className="space-y-1">
                              <div className="flex gap-2 flex-wrap">
                                <Badge
                                  className={`text-xs ${
                                    fmsScores["Shoulder Mobility"] === 0
                                      ? "bg-red-100 text-red-800"
                                      : fmsScores["Shoulder Mobility"] === 1
                                        ? "bg-yellow-100 text-yellow-800"
                                        : fmsScores["Shoulder Mobility"] === 2
                                          ? "bg-blue-100 text-blue-800"
                                          : "bg-green-100 text-green-800"
                                  }}`}
                                >
                                  SM: {fmsScores["Shoulder Mobility"] || 0}
                                </Badge>
                                <Badge
                                  className={`text-xs ${
                                    fmsScores["Active Straight-Leg Raise"] === 0
                                      ? "bg-red-100 text-red-800"
                                      : fmsScores["Active Straight-Leg Raise"] === 1
                                        ? "bg-yellow-100 text-yellow-800"
                                        : fmsScores["Active Straight-Leg Raise"] === 2
                                          ? "bg-blue-100 text-blue-800"
                                          : "bg-green-100 text-green-800"
                                  }}`}
                                >
                                  ASLR: {fmsScores["Active Straight-Leg Raise"] || 0}
                                </Badge>
                              </div>
                              <div className="flex gap-2 flex-wrap">
                                <Badge
                                  className={`text-xs ${
                                    fmsScores["Rotary Stability"] === 0
                                      ? "bg-red-100 text-red-800"
                                      : fmsScores["Rotary Stability"] === 1
                                        ? "bg-yellow-100 text-yellow-800"
                                        : fmsScores["Rotary Stability"] === 2
                                          ? "bg-blue-100 text-blue-800"
                                          : "bg-green-100 text-green-800"
                                  }}`}
                                >
                                  RS: {fmsScores["Rotary Stability"] || 0}
                                </Badge>
                                <Badge
                                  className={`text-xs ${
                                    fmsScores["Trunk Stability Push-Up"] === 0
                                      ? "bg-red-100 text-red-800"
                                      : fmsScores["Trunk Stability Push-Up"] === 1
                                        ? "bg-yellow-100 text-yellow-800"
                                        : fmsScores["Trunk Stability Push-Up"] === 2
                                          ? "bg-blue-100 text-blue-800"
                                          : "bg-green-100 text-green-800"
                                  }}`}
                                >
                                  TSPU: {fmsScores["Trunk Stability Push-Up"] || 0}
                                </Badge>
                              </div>
                              <div className="flex gap-2 flex-wrap">
                                <Badge
                                  className={`text-xs ${
                                    fmsScores["Hurdle Step"] === 0
                                      ? "bg-red-100 text-red-800"
                                      : fmsScores["Hurdle Step"] === 1
                                        ? "bg-yellow-100 text-yellow-800"
                                        : fmsScores["Hurdle Step"] === 2
                                          ? "bg-blue-100 text-blue-800"
                                          : "bg-green-100 text-green-800"
                                  }}`}
                                >
                                  HS: {fmsScores["Hurdle Step"] || 0}
                                </Badge>
                                <Badge
                                  className={`text-xs ${
                                    fmsScores["In-Line Lunge"] === 0
                                      ? "bg-red-100 text-red-800"
                                      : fmsScores["In-Line Lunge"] === 1
                                        ? "bg-yellow-100 text-yellow-800"
                                        : fmsScores["In-Line Lunge"] === 2
                                          ? "bg-blue-100 text-blue-800"
                                          : "bg-green-100 text-green-800"
                                  }}`}
                                >
                                  IL: {fmsScores["In-Line Lunge"] || 0}
                                </Badge>
                                <Badge
                                  className={`text-xs ${
                                    fmsScores["Deep Squat"] === 0
                                      ? "bg-red-100 text-red-800"
                                      : fmsScores["Deep Squat"] === 1
                                        ? "bg-yellow-100 text-yellow-800"
                                        : fmsScores["Deep Squat"] === 2
                                          ? "bg-blue-100 text-blue-800"
                                          : "bg-green-100 text-green-800"
                                  }}`}
                                >
                                  DSQ: {fmsScores["Deep Squat"] || 0}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <Input
                        id={test.field}
                        type="number"
                        step="0.1"
                        placeholder={`Εισάγετε ${test.unit}`}
                        value={testData[test.field] || ""}
                        onChange={(e) => handleInputChange(test.field, e.target.value)}
                      />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Strength Tests */}
        <TabsContent value="strength">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-red-500 text-white">
                  <Weight className="h-5 w-5" />
                </div>
                Τεστ Δύναμης
              </CardTitle>
              <CardDescription>Καταγράψτε τα τεστ δύναμης</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="exercise">Άσκηση</Label>
                  <Select value={selectedStrengthExercise} onValueChange={setSelectedStrengthExercise}>
                    <SelectTrigger>
                      <SelectValue placeholder="Επιλέξτε άσκηση..." />
                    </SelectTrigger>
                    <SelectContent>
                      {exercises.map((exercise) => (
                        <SelectItem key={exercise.id} value={exercise.id}>
                          {exercise.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {selectedStrengthExercise && (
                <div className="mt-4">
                  <h3 className="text-lg font-semibold mb-2">Προσπάθειες</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="weight">Βάρος (kg)</Label>
                      <Input
                        id="weight"
                        type="number"
                        step="0.1"
                        placeholder="Εισάγετε κιλά"
                        value={currentWeight}
                        onChange={(e) => setCurrentWeight(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="velocity">Ταχύτητα (m/s)</Label>
                      <Input
                        id="velocity"
                        type="number"
                        step="0.01"
                        placeholder="Εισάγετε ταχύτητα"
                        value={currentVelocity}
                        onChange={(e) => setCurrentVelocity(e.target.value)}
                      />
                    </div>
                  </div>
                  <Button onClick={addStrengthAttempt} className="mt-4">
                    Προσθήκη Προσπάθειας
                  </Button>

                  {strengthAttempts.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-md font-semibold mb-2">Λίστα Προσπαθειών</h4>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th
                                scope="col"
                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                Βάρος
                              </th>
                              <th
                                scope="col"
                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                Ταχύτητα
                              </th>
                              <th
                                scope="col"
                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                              >
                                1RM
                              </th>
                              <th scope="col" className="relative px-6 py-3">
                                <span className="sr-only">Ενέργειες</span>
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {strengthAttempts.map((attempt, index) => (
                              <tr key={index}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{attempt.weight}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {attempt.velocity}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => markAs1RM(index)}
                                    className={attempt.is_1rm ? "bg-green-500 text-white hover:bg-green-700" : ""}
                                  >
                                    {attempt.is_1rm ? "1RM" : "Mark as 1RM"}
                                  </Button>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                  <Button variant="ghost" size="sm" onClick={() => removeStrengthAttempt(index)}>
                                    Διαγραφή
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Endurance Tests */}
        <TabsContent value="endurance">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-purple-500 text-white">
                  <Heart className="h-5 w-5" />
                </div>
                Τεστ Αντοχής
              </CardTitle>
              <CardDescription>Καταγράψτε τα τεστ αντοχής</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="pushUpExercise">Push-Up Exercise</Label>
                  <Select value={selectedPushUpExercise} onValueChange={setSelectedPushUpExercise}>
                    <SelectTrigger>
                      <SelectValue placeholder="Επιλέξτε άσκηση..." />
                    </SelectTrigger>
                    <SelectContent>
                      {exercises.map((exercise) => (
                        <SelectItem key={exercise.id} value={exercise.id}>
                          {exercise.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="pushUpReps">Push-Up Reps</Label>
                  <Input
                    id="pushUpReps"
                    type="number"
                    placeholder="Εισάγετε επαναλήψεις"
                    value={pushUpReps}
                    onChange={(e) => setPushUpReps(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="pullUpExercise">Pull-Up Exercise</Label>
                  <Select value={selectedPullUpExercise} onValueChange={setSelectedPullUpExercise}>
                    <SelectTrigger>
                      <SelectValue placeholder="Επιλέξτε άσκηση..." />
                    </SelectTrigger>
                    <SelectContent>
                      {exercises.map((exercise) => (
                        <SelectItem key={exercise.id} value={exercise.id}>
                          {exercise.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="pullUpReps">Pull-Up Reps</Label>
                  <Input
                    id="pullUpReps"
                    type="number"
                    placeholder="Εισάγετε επαναλήψεις"
                    value={pullUpReps}
                    onChange={(e) => setPullUpReps(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="farmerTime">Farmer's Walk Time (sec)</Label>
                  <Input
                    id="farmerTime"
                    type="number"
                    placeholder="Εισάγετε χρόνο"
                    value={farmerTime}
                    onChange={(e) => setFarmerTime(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="farmerSpeed">Farmer's Walk Speed (m/s)</Label>
                  <Input
                    id="farmerSpeed"
                    type="number"
                    placeholder="Εισάγετε ταχύτητα"
                    value={farmerSpeed}
                    onChange={(e) => setFarmerSpeed(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="farmerWeight">Farmer's Walk Weight (kg)</Label>
                  <Input
                    id="farmerWeight"
                    type="number"
                    placeholder="Εισάγετε βάρος"
                    value={farmerWeight}
                    onChange={(e) => setFarmerWeight(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="farmerDistance">Farmer's Walk Distance (m)</Label>
                  <Input
                    id="farmerDistance"
                    type="number"
                    placeholder="Εισάγετε απόσταση"
                    value={farmerDistance}
                    onChange={(e) => setFarmerDistance(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sprintTime">Sprint Time (sec)</Label>
                  <Input
                    id="sprintTime"
                    type="number"
                    placeholder="Εισάγετε χρόνο"
                    value={sprintTime}
                    onChange={(e) => setSprintTime(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sprintDistance">Sprint Distance (m)</Label>
                  <Input
                    id="sprintDistance"
                    type="number"
                    placeholder="Εισάγετε απόσταση"
                    value={sprintDistance}
                    onChange={(e) => setSprintDistance(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sprintSpeed">Sprint Speed (m/s)</Label>
                  <Input
                    id="sprintSpeed"
                    type="number"
                    placeholder="Εισάγετε ταχύτητα"
                    value={sprintSpeed}
                    onChange={(e) => setSprintSpeed(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="masExercise">MAS Exercise</Label>
                  <Select value={selectedMasExercise} onValueChange={setSelectedMasExercise}>
                    <SelectTrigger>
                      <SelectValue placeholder="Επιλέξτε άσκηση..." />
                    </SelectTrigger>
                    <SelectContent>
                      {exercises.map((exercise) => (
                        <SelectItem key={exercise.id} value={exercise.id}>
                          {exercise.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="masTime">MAS Time (min)</Label>
                  <Input
                    id="masTime"
                    type="number"
                    placeholder="Εισάγετε χρόνο"
                    value={masTime}
                    onChange={(e) => setMasTime(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="masDistance">MAS Distance (m)</Label>
                  <Input
                    id="masDistance"
                    type="number"
                    placeholder="Εισάγετε απόσταση"
                    value={masDistance}
                    onChange={(e) => setMasDistance(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="masResult">MAS Result (m/s)</Label>
                  <Input id="masResult" type="number" placeholder="Αποτέλεσμα" value={masResult} disabled />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Jumping Tests */}
        <TabsContent value="jumping">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-yellow-500 text-white">
                  <Zap className="h-5 w-5" />
                </div>
                Τεστ Αλμάτων
              </CardTitle>
              <CardDescription>Καταγράψτε τα τεστ αλμάτων</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {testCategories[4].tests.map((test) => (
                  <div key={test.field} className="space-y-2">
                    <Label htmlFor={test.field} className="flex items-center justify-between">
                      {test.name}
                      <Badge className="bg-blue-100 text-blue-700">{test.unit}</Badge>
                    </Label>
                    <Input
                      id={test.field}
                      type="number"
                      step="0.1"
                      placeholder={`Εισάγετε ${test.unit}`}
                      value={testData[test.field] || ""}
                      onChange={(e) => handleInputChange(test.field, e.target.value)}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Notes Section */}
      <Card>
        <CardHeader>
          <CardTitle>Σημειώσεις</CardTitle>
          <CardDescription>Προσθέστε επιπλέον σημειώσεις για τον αθλητή</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4">
            <div>
              <Label htmlFor="notes">Σημειώσεις</Label>
              <Input
                id="notes"
                placeholder="Εισάγετε σημειώσεις..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
